execute in minecraft:the_end run summon item 0 100 0 {Age:-32768,Item:{id:"minecraft:nether_star",count:1}}
tellraw @a {"translate": "matcha.gen_key_104","color":"gray"}
scoreboard players set gamerule gamerule_safe_surface 1
execute if score current_world_settings_difficulty difficulty_score matches 2 run tellraw @a ["",{"translate": "matcha.smart_key_2"},{"translate": "matcha.gen_key_106","bold":true,"color":"red"},{"text":"\n"},{"translate": "matcha.gen_key_109","color":"gray"}]
execute if score current_world_settings_difficulty difficulty_score matches 1 run tellraw @a ["",{"translate": "matcha.smart_key_3"},{"translate": "matcha.gen_key_107","bold":true,"color":"gold"},{"text":"\n"},{"translate": "matcha.gen_key_109","color":"gray"}]
execute if score current_world_settings_difficulty difficulty_score matches 1 run difficulty normal
execute if score current_world_settings_difficulty difficulty_score matches 2 run difficulty hard
execute store result score current_world_settings_difficulty difficulty_score run difficulty