function main:environmental/load_day_cycle_extender
function main:setup/scoreboard
function main:setup/gamerules
tellraw @a {"bold":false,"color":"#65E082","translate": "matcha.gen_key_117"}
tellraw @a [{"bold":false,"color":"#8fb398","translate": "matcha.gen_key_118"},{"bold":true,"color":"#61bb78","translate": "matcha.smart_key_4"}]
execute if score current_world_settings_difficulty difficulty_score matches 1 run tellraw @a ["",{"text":"[⛏]","color":"green"},{"translate": "matcha.smart_key_5"},{"translate": "matcha.gen_key_108","bold":true,"color":"green"},{"translate": "matcha.smart_key_6"},{"translate": "matcha.gen_key_124","color":"gray"}]
execute if score current_world_settings_difficulty difficulty_score matches 2 run tellraw @a ["",{"text":"[\u2620]","color":"gold"},{"translate": "matcha.smart_key_7"},{"translate": "matcha.gen_key_107","bold":true,"color":"gold"},{"translate": "matcha.smart_key_8"},{"translate": "matcha.gen_key_124","color":"gray"}]
execute if score current_world_settings_difficulty difficulty_score matches 3 run tellraw @a ["",{"text":"[\u2620\u2620\u2620]","color":"red"},{"translate": "matcha.smart_key_9"},{"translate": "matcha.gen_key_106","bold":true,"color":"red"},{"translate": "matcha.smart_key_10"},{"translate": "matcha.gen_key_124","color":"gray"}]
# execute as @a run function main:setup/update_players